console.log("linked file");

function validateName(name)
{
    var name=name.value;
    console.log(name);
    if(name.length<=5)
    {
        alert("Wrong input");
    }
}
{
    var lastname=lastname.value;
    console.log(lastname);
    if(lastname.length<=5)
    {
        alert("Wrong input");
    }
}
function validatePhone(phone){
    var phone=phone.value;
    if(phone.length!=10)
    {
        alert("Error! Plz enter a correct number");
    }

}

function validateMessage(message){
    var message=message.value;
    if(message.length>=50)
    {
        alert("Error! at least 50 char");
    }

}
function validateEmail(email){
    let regex = /^\S+@\S+\.\S+$/;
    let emailValue = email.value;
    if(!regex.test(emailValue)){
        alert("Error! Enter a valid email")
    }
}